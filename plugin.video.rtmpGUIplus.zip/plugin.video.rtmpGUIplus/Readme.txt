Este es el plugin RTMPGUI+ modificado para canales Chilenos, para que prueben y vean funcionando el punto de partida.

La idea es llegar a un plugin completamente personalizado